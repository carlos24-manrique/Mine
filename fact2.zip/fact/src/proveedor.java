public class proveedor extends recibo {
    private int codigo;
    private String razonsocial;

    public proveedor() {
    }

    public proveedor(char tipo, int numero, java.util.Date fecha, String proveedor, float monto, String detalle,
            int codigo, String razonsocial) {
        super(tipo, numero, fecha, proveedor, monto, detalle);
        this.codigo = codigo;
        this.razonsocial = razonsocial;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getRazonsocial() {
        return razonsocial;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public void setRazonsocial(String razonsocial) {
        this.razonsocial = razonsocial;
    }

}
