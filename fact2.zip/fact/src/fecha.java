public class fecha extends comprobante {
    private int dia;
    private int mes;
    private int anio;

    public fecha() {
    }

    public fecha(char tipo, int numero, java.util.Date fecha, String proveedor, float monto, String detalle, int dia,
            int mes, int anio) {
        super(tipo, numero, fecha);
        this.dia = dia;
        this.mes = mes;
        this.anio = anio;
    }

    public int getDia() {
        return dia;
    }

    public int getMes() {
        return mes;
    }

    public int getAnio() {
        return anio;
    }

    public void setDia(int dia) {
        this.dia = dia;
    }

    public void setMes(int mes) {
        this.mes = mes;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

}
