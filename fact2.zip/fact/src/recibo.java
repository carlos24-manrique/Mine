import java.util.Date;

public class recibo extends comprobante {
    private String proveedor;
    private float monto;
    private String detalle;

    public recibo() {
    }

    public recibo(char tipo, int numero, Date fecha, String proveedor, float monto, String detalle) {
        super(tipo, numero, fecha);
        this.proveedor = proveedor;
        this.monto = monto;
        this.detalle = detalle;
    }

    public String getProveedor() {
        return proveedor;
    }

    public float getMonto() {
        return monto;
    }

    public String getDetalle() {
        return detalle;
    }

    public void setProveedor(String proveedor) {
        this.proveedor = proveedor;
    }

    public void setMonto(float monto) {
        this.monto = monto;
    }

    public void setDetalle(String detalle) {
        this.detalle = detalle;
    }

}
