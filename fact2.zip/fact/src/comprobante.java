import java.util.Date;

public class comprobante {
    private char tipo;
    private int numero;
    private java.util.Date fecha;

    public comprobante() {
    }

    public comprobante(char tipo, int numero, Date fecha) {
        this.tipo = tipo;
        this.numero = numero;
        this.fecha = fecha;
    }

    public char getTipo() {
        return tipo;
    }

    public int getNumero() {
        return numero;
    }

    public java.util.Date getFecha() {
        return fecha;
    }

    public void setTipo(char tipo) {
        this.tipo = tipo;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public void setFecha(java.util.Date fecha) {
        this.fecha = fecha;
    }

}
