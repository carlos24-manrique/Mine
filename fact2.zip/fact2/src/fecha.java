public class fecha extends comprobante {
    private int dia;
    private int mes;
    private int anio;

    public fecha() {
    }

    public fecha(int codigo, String descripcion, float precio, char tipo, int numero, java.util.Date fecha,
            int dia, int mes, int anio) {
        super(codigo, descripcion, precio, tipo, numero, fecha);
        this.dia = dia;
        this.mes = mes;
        this.anio = anio;
    }

    public int getDia() {
        return dia;
    }

    public void setDia(int dia) {
        this.dia = dia;
    }

    public int getMes() {
        return mes;
    }

    public void setMes(int mes) {
        this.mes = mes;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

}
