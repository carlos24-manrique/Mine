public class comprobante extends producto {
    private char tipo;
    private int numero;
    private java.util.Date fecha;

    public comprobante() {
    }

    public comprobante(int codigo, String descripcion, float precio, char tipo, int numero, java.util.Date fecha) {
        super(codigo, descripcion, precio);
        this.tipo = tipo;
        this.numero = numero;
        this.fecha = fecha;
    }

    public char getTipo() {
        return tipo;
    }

    public int getNumero() {
        return numero;
    }

    public java.util.Date getFecha() {
        return fecha;
    }

    public void setTipo(char tipo) {
        this.tipo = tipo;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public void setFecha(java.util.Date fecha) {
        this.fecha = fecha;
    }

}
