import java.util.Date;

public class cliente extends factura {
    private int codigo;
    private String razonSocial;

    public cliente() {
    }

    public cliente(int codigo, String descripcion, float precio, char tipo, int numero, Date fecha, float total,
            int codigo2, String razonSocial) {
        super(codigo, descripcion, precio, tipo, numero, fecha, total);
        this.codigo = codigo2;
        this.razonSocial = razonSocial;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getRazonSocial() {
        return razonSocial;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public void setRazonSocial(String razonSocial) {
        this.razonSocial = razonSocial;
    }

}
