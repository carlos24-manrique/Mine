public class factura extends comprobante {
    private float total;

    public factura() {
    }

    public factura(int codigo, String descripcion, float precio, char tipo, int numero, java.util.Date fecha,
            float total) {
        super(codigo, descripcion, precio, tipo, numero, fecha);
        this.total = total;
    }

    public float getTotal() {
        return total;
    }

    public void setTotal(float total) {
        this.total = total;
    }

}
